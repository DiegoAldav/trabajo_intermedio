package programaCorrelativas;

import correlativas.*;

import java.nio.file.Files;
import java.nio.file.Paths;

public class CorrelativasProg {
    public static void main(String[] args) throws Exception {

        Materia[] mat = new Materia[12];
        mat[0] = new Materia("programacion 0",null);
        mat[1] = new Materia("programacion I", null);
        mat[1].agregarCorrelativa(mat[0]);
        mat[2] = new Materia("programacion II", null);
        mat[2].agregarCorrelativa(mat[1]);
        mat[3] = new Materia("programacion III", null);
        mat[3].agregarCorrelativa(mat[2]);

        mat[4] = new Materia("base de datos 0",null);
        mat[5] = new Materia("base de datos I",null);
        mat[5].agregarCorrelativa(mat[4]);
        mat[6] = new Materia("base de datos II",null);
        mat[6].agregarCorrelativa(mat[5]);
        mat[7] = new Materia("base de datos III",null);
        mat[7].agregarCorrelativa(mat[6]);

        mat[8] = new Materia("java 0",null);
        mat[9] = new Materia("java I",null);
        mat[9].agregarCorrelativa(mat[8]);
        mat[10] = new Materia("java II",null);
        mat[10].agregarCorrelativa(mat[9]);
        mat[11] = new Materia("java III", null);
        mat[11].agregarCorrelativa(mat[10]);


        Alumno[] alum = new Alumno[3];
        alum[0] = new Alumno("Jose Rodriguez","001", null);
        alum[0].agregarMateriaAprobada(mat[1]);
        alum[0].agregarMateriaAprobada(mat[6]);
        alum[0].agregarMateriaAprobada(mat[8]);

        alum[1] = new Alumno("Vanesa Sosa","002",null);
        alum[1].agregarMateriaAprobada(mat[0]);
        alum[1].agregarMateriaAprobada(mat[6]);
        alum[1].agregarMateriaAprobada(mat[9]);

        alum[2] = new Alumno("Lucia Perez","003",null);
        alum[2].agregarMateriaAprobada(mat[1]);
        alum[2].agregarMateriaAprobada(mat[5]);
        alum[2].agregarMateriaAprobada(mat[10]);

        Inscripcion[] inscripciones = new Inscripcion[7];
        inscripciones[0] = new Inscripcion(alum[0], mat[2]);
        inscripciones[1] = new Inscripcion(alum[0],mat[7]);
        inscripciones[2] = new Inscripcion(alum[0],mat[9]);
        inscripciones[3] = new Inscripcion(alum[1],mat[7]);
        inscripciones[4] = new Inscripcion(alum[1],mat[11]);
        inscripciones[5] = new Inscripcion(alum[2],mat[6]);
        inscripciones[6] = new Inscripcion(alum[2],mat[10]);

        baseDeDatosAyM b1 = new baseDeDatosAyM();
        //baseDeDatosAyM b1 = new baseDeDatosAyM(alum,mat);


        LecturaInscripciones L1 = new LecturaInscripciones("/home/mustafa/trabajos/correlativas8/inscripciones.csv", alum, mat);

        Inscripcion[] inscripArchivo = new Inscripcion[L1.lecturaInscripciones().size()];

        String b = "------------------------------------------------inscripciones------------------------------------------------\n"+
                   "Alumno                   Materia inscripta        Materias Aprobadas                                  Aprobacion    \n";

        String c = "";
        for (int i = 0; i < L1.lecturaInscripciones().size(); i++) {
            try {
                String[] list = L1.lecturaInscripciones().get(i).split(",");

                inscripArchivo[i] = new Inscripcion(L1.obtenerAlumno(list[0]), L1.obtenerMateria(list[1]));


                c += String.format("%-25s%-25s%-18s%-20s%-14s%s",list[0], list[1],L1.obtenerAlumno(list[0]).getMateriasAprobadas().get(0).getNombre(),L1.obtenerAlumno(list[0]).getMateriasAprobadas().get(1).getNombre(),L1.obtenerAlumno(list[0]).getMateriasAprobadas().get(2).getNombre(),inscripArchivo[i].aprobadaAPROB()+"\n");
                //System.out.println(c);
            } catch ( /*NullPointer*/Exception ex) {
               // System.out.println(ex);
            }
        }
        System.out.print(b);
        System.out.println(c);
        System.out.println();

        String a = "------------------------------inscripciones------------------------------\n"+
                   "Alumno                      Materia inscripta             Aprobacion    \n";
        System.out.print(a);

        String s = "";
        for (int i = 0; i < L1.lecturaInscripciones().size(); i++) {
            try {
                String[] list = L1.lecturaInscripciones().get(i).split(",");

                inscripArchivo[i] = new Inscripcion(L1.obtenerAlumno(list[0]), L1.obtenerMateria(list[1]));

                s += String.format("%-28s%-30s%s",list[0], list[1],inscripArchivo[i].aprobadaAPROB1()+"\n");

            } catch ( /*NullPointer*/Exception ex) {
                // System.out.println(ex);
            }
        }

        System.out.println(s);
        Files.writeString(Paths.get("/home/mustafa/trabajos/correlativas8/aprobaciones.txt" ), a+s+"\n"+b+c );

    }
}
