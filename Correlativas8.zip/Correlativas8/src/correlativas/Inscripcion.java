package correlativas;

public class Inscripcion {
    Alumno alumno;
    Materia materia;

    public Inscripcion() {}

    public Inscripcion(Alumno unAlumno, Materia unaMateria) {
        this.alumno = unAlumno;
        this.materia = unaMateria;
    }

    public void setMateria(Materia materia) {
        this.materia = materia;
    }

    public Materia getMateria() {
        return materia;
    }

    public void setAlumno(Alumno alumno) {
        this.alumno = alumno;
    }

    public Alumno getAlumno() {
        return alumno;
    }

    public boolean aprobada() {
        boolean aprob = false;
        for (int i = 0 ; i < materia.getCorrelativas().size(); i++) {
            for (int j = 0; j < alumno.getMateriasAprobadas().size(); j++) {
                aprob = this.alumno.getMateriasAprobadas().get(j) == this.materia.getCorrelativas().get(i);
            }
        }
        return aprob;
    }

    public String aprobadaAPROB() {
        String a = "rechazado";
        String b = "";
        if (this.alumno.getLegajo().equals("99999")) {
            return a = "No existe el alumno/a";
        }
        for (int i = 0 ; i < materia.getCorrelativas().size(); i++) {
            for (int j = 0; j < alumno.getMateriasAprobadas().size(); j++) {

                if (this.alumno.getMateriasAprobadas().get(j) == this.materia.getCorrelativas().get(i)/*) == true*/) {
                    return a = "aprobada";
                }

                if (this.getAlumno().getMateriasAprobadas().get(j) == this.getMateria()) {
                   return a = "rechazada, la materia ya esta aprobada";
                }
            }
        }
        return a;
    }

    public String aprobadaAPROB1() {
        String a = "rechazado";
        String b = "";
        if (this.alumno.getLegajo().equals("99999")) {
            return a = "No existe el alumno/a";
        }
        for (int i = 0 ; i < materia.getCorrelativas().size(); i++) {
            for (int j = 0; j < alumno.getMateriasAprobadas().size(); j++) {

                if (this.alumno.getMateriasAprobadas().get(j).getNombre() == this.materia.getCorrelativas().get(i).getNombre()/*) == true*/) {
                    return a = "aprobada";
                }

                if (this.getAlumno().getMateriasAprobadas().get(j).getNombre() == this.getMateria().getNombre()) {
                    return a = "rechazada, la materia ya esta aprobada";
                }
            }
        }
        return a;
    }



}
