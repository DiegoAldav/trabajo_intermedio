package correlativas;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;

public class LecturaInscripciones {

    String archivo;
    Alumno[] alumnos;
    Materia[] materias;


    public LecturaInscripciones() {}

    public LecturaInscripciones(String unaDir) {
        this.archivo = unaDir;
    }

    public LecturaInscripciones(String unaDir,Alumno[] alumnos) {

        this.archivo = unaDir;
        this.alumnos = alumnos;
    }

    public LecturaInscripciones(String unaDir, Alumno[] alumnos, Materia[] materias) {
        this.archivo = unaDir;
        this.alumnos = alumnos;
        this.materias = materias;
    }

    public void setMaterias(Materia[] materias) {
        this.materias = materias;
    }

    public Materia[] getMaterias() {
        return materias;
    }

    public Alumno[] getAlumnos() {
        return alumnos;
    }

    public void setAlumnos(Alumno[] alumnos) {
        this.alumnos = alumnos;
    }

    public void setDir(String dir) {
        this.archivo = dir;
    }

    public String getDir() {
        return archivo;
    }

    public Alumno obtenerAlumno(String unNombre) {
        Alumno alumnox = new Alumno();
        for (int i = 0; i < alumnos.length; i++) {
            if (alumnos[i].getNombre().equals(unNombre)) {
                alumnox = alumnos[i];
                return alumnox;
            }
        }
        alumnox = new Alumno(unNombre, "99999", null);
        Materia sinDatos = new Materia("Sin Datos",null);
        alumnox.agregarMateriaAprobada(sinDatos);
        alumnox.agregarMateriaAprobada(sinDatos);
        alumnox.agregarMateriaAprobada(sinDatos);
        return alumnox;
    }

    public Materia obtenerMateria(String unaMateria) {
        Materia materiax = new Materia();
        for (int i = 0; i < materias.length; i++) {
            if (materias[i].getNombre().equals(unaMateria)) {
                materiax = materias[i];
            }
        }
        return materiax;
    }

    public List<String> lecturaInscripciones() throws Exception {
        File result = new File(archivo);
        if (!result.exists()) {
            System.out.println("no encuentra el archivo inscripciones.csv\npuede que la direccion del archivo esta mal\no puede que el archivo no exista");
            System.exit(0);
        }

        List<String> inscripcionesAyM = Files.readAllLines(Paths.get(archivo));
        inscripcionesAyM.remove(0);

        return inscripcionesAyM;
    }

}
