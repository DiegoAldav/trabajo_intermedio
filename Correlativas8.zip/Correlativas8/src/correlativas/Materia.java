package correlativas;

import java.util.ArrayList;
import java.util.List;

public class Materia {
    String nombre;
    List<Materia> correlativas;

    public Materia() {}

    public Materia(String nombre, List<Materia> correlativas) {
        this.nombre = nombre;
        this.correlativas = new ArrayList<Materia>();
    }
    /*public Materia(String nombre,Materia unaCorrelativa) throws Exception {
        this.nombre = nombre;
        this.correlativas = new ArrayList<Materia>();
        this.correlativas.add(unaCorrelativa);
    }*/

    public List<Materia> getCorrelativas() {
        return correlativas;
    }
    public String getNombreCorrelativa() {
        return correlativas.get(0).nombre;
    }
    public void agregarCorrelativa(Materia unaMateria) {
        this.correlativas.add(unaMateria);
    }
    public void quitarCorrelativa(Materia unaMateria) {
        this.correlativas.remove(unaMateria);
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getNombre() {
        return nombre;
    }

    public boolean puedeCursar(Alumno unAlumno) {
        boolean cursar = unAlumno.getMateriasAprobadas().get(0) == correlativas.get(0);
        return cursar;
    }

    public String puedeCursarOno(Alumno unAlumno) {
        String a = "no puede cursar";
        for (int i = 0; i < unAlumno.getMateriasAprobadas().size(); i++){
            for (int j = 0; j < correlativas.size(); j++) {
                if (unAlumno.materiasAprobadas.get(i) == correlativas.get(j)) {
                    a = "puede cursar";
                }
            }
        }

        return a;
    }
}
