package correlativas;

import java.util.ArrayList;
import java.util.List;

public class Alumno {
    String nombre;
    String legajo;
    List<Materia> materiasAprobadas;


    public Alumno() {}

    public Alumno(String nombre, String legajo, List<Materia> materiasAprobadas) {
        this.nombre = nombre;
        this.legajo = legajo;
        this.materiasAprobadas = new ArrayList<Materia>();
    }

    public List<Materia> getMateriasAprobadas() {
        return materiasAprobadas;
    }

    public void setMateriasAprobadas(List<Materia> materiasAprobadas) {
        this.materiasAprobadas = materiasAprobadas;
    }

    public void agregarMateriaAprobada(Materia unaMateria) {
        this.materiasAprobadas.add(unaMateria);
    }
    public void quitarMateriaAprobada(Materia unaMateria) {
        this.materiasAprobadas.remove(unaMateria);
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getNombre() {
        return nombre;
    }

    public void setLegajo(String legajo) {
        this.legajo = legajo;
    }

    public String getLegajo() {
        return legajo;
    }




}
