package correlativas;

public class baseDeDatosAyM {

    Alumno[] alumnos;
    Materia[] materias;

    public baseDeDatosAyM() {}
    public baseDeDatosAyM(Alumno[] alumnos,Materia[] materias) {
        this.alumnos = alumnos;
        this.materias = materias;
    }

    public Materia[] cargarMaterias() {

        Materia[] mat = new Materia[12];
        mat[0] = new Materia("programacion 0",null);
        mat[1] = new Materia("programacion I", null);
        mat[1].agregarCorrelativa(mat[0]);
        mat[2] = new Materia("programacion II", null);
        mat[2].agregarCorrelativa(mat[1]);
        mat[3] = new Materia("programacion III", null);
        mat[3].agregarCorrelativa(mat[2]);

        mat[4] = new Materia("base de datos 0",null);
        mat[5] = new Materia("base de datos I",null);
        mat[5].agregarCorrelativa(mat[4]);
        mat[6] = new Materia("base de datos II",null);
        mat[6].agregarCorrelativa(mat[5]);
        mat[7] = new Materia("base de datos III",null);
        mat[7].agregarCorrelativa(mat[6]);

        mat[8] = new Materia("java 0",null);
        mat[9] = new Materia("java I",null);
        mat[9].agregarCorrelativa(mat[8]);
        mat[10] = new Materia("java II",null);
        mat[10].agregarCorrelativa(mat[9]);
        mat[11] = new Materia("java III", null);
        mat[11].agregarCorrelativa(mat[10]);

         Alumno[] alum = new Alumno[3];
        alum[0] = new Alumno("Jose Rodriguez","001", null);
        alum[0].agregarMateriaAprobada(mat[1]);
        alum[0].agregarMateriaAprobada(mat[6]);
        alum[0].agregarMateriaAprobada(mat[8]);

        alum[1] = new Alumno("Vanesa Sosa","002",null);
        alum[1].agregarMateriaAprobada(mat[0]);
        alum[1].agregarMateriaAprobada(mat[6]);
        alum[1].agregarMateriaAprobada(mat[9]);

        alum[2] = new Alumno("Lucia Perez","003",null);
        alum[2].agregarMateriaAprobada(mat[1]);
        alum[2].agregarMateriaAprobada(mat[5]);
        alum[2].agregarMateriaAprobada(mat[10]);

        return mat;
    }

    public Alumno[] cargarAlumnos() {

        Alumno[] alum = new Alumno[3];
        alum[0] = new Alumno("Jose Rodriguez","001", null);
        alum[0].agregarMateriaAprobada(this.cargarMaterias()[1]);
        alum[0].agregarMateriaAprobada(this.cargarMaterias()[6]);
        alum[0].agregarMateriaAprobada(this.cargarMaterias()[8]);

        alum[1] = new Alumno("Vanesa Sosa","002",null);
        alum[1].agregarMateriaAprobada(this.cargarMaterias()[0]);
        alum[1].agregarMateriaAprobada(this.cargarMaterias()[6]);
        alum[1].agregarMateriaAprobada(this.cargarMaterias()[9]);

        alum[2] = new Alumno("Lucia Perez","003",null);
        alum[2].agregarMateriaAprobada(this.cargarMaterias()[1]);
        alum[2].agregarMateriaAprobada(this.cargarMaterias()[5]);
        alum[2].agregarMateriaAprobada(this.cargarMaterias()[10]);

        return alum;
    }
}
